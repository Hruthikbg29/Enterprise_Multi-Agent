import { beforeEach, describe, expect, it, vi } from 'vitest';

const { mockQuery } = vi.hoisted(() => ({
  mockQuery: vi.fn()
}));

vi.mock('@anthropic-ai/claude-agent-sdk', () => ({
  query: mockQuery
}));

import { CodeReviewOrchestrator } from '../src/orchestrator';

const validReport = {
  pullRequest: {
    owner: 'octocat',
    repo: 'Hello-World',
    number: 1
  },
  fileReviews: [],
  summary: {
    totalFiles: 0,
    overallScore: 100,
    criticalIssues: 0,
    highPriorityTests: 0,
    refactoringOpportunities: 0
  },
  recommendations: [],
  metadata: {
    analyzedAt: new Date().toISOString(),
    duration: 100,
    agentVersions: {
      'code-quality-analyzer': 'test',
      'test-coverage-analyzer': 'test',
      'refactoring-suggester': 'test'
    }
  }
};

async function* resultStream(message: unknown) {
  yield message;
}

describe('CodeReviewOrchestrator', () => {
  beforeEach(() => {
    mockQuery.mockReset();
  });

  it('initializes with default options', () => {
    expect(new CodeReviewOrchestrator()).toBeInstanceOf(CodeReviewOrchestrator);
  });

  it('returns a validated ReviewReport from successful SDK output', async () => {
    mockQuery.mockImplementation(() => resultStream({
        type: 'result',
        subtype: 'success',
        structured_output: validReport
      }));

    const orchestrator = new CodeReviewOrchestrator();

    await expect(
      orchestrator.reviewPullRequest('octocat', 'Hello-World', 1)
    ).resolves.toEqual(validReport);

    expect(mockQuery).toHaveBeenCalledOnce();
  });

  it('rejects invalid structured output', async () => {
    mockQuery.mockImplementation(() => resultStream({
        type: 'result',
        subtype: 'success',
        structured_output: {
          invalid: true
        }
      }));

    const orchestrator = new CodeReviewOrchestrator();

    await expect(
      orchestrator.reviewPullRequest('octocat', 'Hello-World', 1)
    ).rejects.toThrow('Invalid ReviewReport');
  });

  it('propagates SDK execution errors', async () => {
    mockQuery.mockImplementation(() => resultStream({
        type: 'result',
        subtype: 'error_during_execution',
        errors: ['GitHub MCP unavailable']
      }));

    const orchestrator = new CodeReviewOrchestrator();

    await expect(
      orchestrator.reviewPullRequest('octocat', 'Hello-World', 1)
    ).rejects.toThrow('GitHub MCP unavailable');
  });

  it('fails when the SDK produces no result', async () => {
    mockQuery.mockReturnValue(resultStream({
      type: 'assistant',
      message: 'no final result'
    }));

    const orchestrator = new CodeReviewOrchestrator();

    await expect(
      orchestrator.reviewPullRequest('octocat', 'Hello-World', 1)
    ).rejects.toThrow('Code review produced no result');
  });
});
