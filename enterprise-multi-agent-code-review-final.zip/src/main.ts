import * as dotenv from 'dotenv';
import { mkdir, writeFile } from 'node:fs/promises';
import { CodeReviewOrchestrator } from './orchestrator';
import { ReportGenerator } from './utils/report-generator';
import {
  logReviewStart,
  logReviewComplete,
  logReviewError
} from './utils/logger';

dotenv.config();

function fail(message: string): never {
  console.error(`❌ ${message}`);
  process.exit(1);
}

function validateConfig(): void {
  const hasAnthropic = Boolean(process.env.ANTHROPIC_API_KEY);
  const hasBedrock =
    Boolean(process.env.AWS_ACCESS_KEY_ID) &&
    Boolean(process.env.AWS_SECRET_ACCESS_KEY);

  if (!hasAnthropic && !hasBedrock) {
    fail(
      'Authentication not configured. Set ANTHROPIC_API_KEY, or configure AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, and AWS_REGION for Bedrock.'
    );
  }

  if (hasBedrock && !process.env.AWS_REGION) {
    fail('AWS_REGION is required when using AWS Bedrock authentication.');
  }

  if (!process.env.ANTHROPIC_MODEL) {
    fail(
      'ANTHROPIC_MODEL is required. Use claude-sonnet-4-5-20250929 for Anthropic API or the appropriate Bedrock model ID.'
    );
  }

  if (hasBedrock) {
    console.log('�� Using AWS Bedrock authentication');
  } else {
    console.log('🔐 Using Anthropic API authentication');
  }
}

async function main(): Promise<void> {
  const [owner, repo, prStr] = process.argv.slice(2);

  if (!owner || !repo || !prStr) {
    fail('Usage: npm run dev <owner> <repo> <pr-number>');
  }

  const prNumber = Number(prStr);

  if (!Number.isInteger(prNumber) || prNumber <= 0) {
    fail(`Invalid PR number: ${prStr}`);
  }

  validateConfig();

  const startTime = Date.now();
  logReviewStart(owner, repo, prNumber);

  try {
    const orchestrator = new CodeReviewOrchestrator();
    const report = await orchestrator.reviewPullRequest(
      owner,
      repo,
      prNumber
    );

    const generator = new ReportGenerator();

    await mkdir('reports', { recursive: true });

    const baseName = `${owner}-${repo}-pr-${prNumber}`;

    await writeFile(
      `reports/${baseName}.md`,
      generator.generateMarkdownReport(report),
      'utf8'
    );

    await writeFile(
      `reports/${baseName}.html`,
      generator.generateHTMLReport(report),
      'utf8'
    );

    await writeFile(
      `reports/${baseName}.json`,
      generator.generateJSONReport(report),
      'utf8'
    );

    const duration = Date.now() - startTime;

    logReviewComplete(
      owner,
      repo,
      prNumber,
      report.summary.overallScore,
      duration
    );

    console.log(`✅ Review completed successfully.`);
    console.log(`📊 Overall score: ${report.summary.overallScore}/100`);
    console.log(`📁 Reports written to reports/`);
  } catch (error) {
    const reviewError =
      error instanceof Error ? error : new Error(String(error));

    logReviewError(owner, repo, prNumber, reviewError);
    console.error(`❌ Error: ${reviewError.message}`);
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(
    `❌ Fatal error: ${error instanceof Error ? error.message : String(error)}`
  );
  process.exitCode = 1;
});
