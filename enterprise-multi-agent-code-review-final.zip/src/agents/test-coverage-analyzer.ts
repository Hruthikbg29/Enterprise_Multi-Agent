import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';

export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Analyzes source code for missing tests, untested paths, edge cases, and test coverage opportunities.',
  tools: ['Read', 'Grep', 'Glob', 'Skill'],
  model: 'inherit',
  prompt: `You are a test coverage analyzer.

Analyze the provided source file and determine what behavior is covered by tests and what important behavior appears untested.

Identify:
- missing test coverage
- untested functions, classes, branches, and edge cases
- the priority of each testing opportunity
- a concrete suggested test

Return results that match the TestCoverageResult schema exactly. Base conclusions only on the available source and test files.`,
};
