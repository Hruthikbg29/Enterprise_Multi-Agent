import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';

export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Analyzes source code for bugs, security issues, performance problems, maintainability concerns, style issues, and best-practice violations.',
  tools: ['Read', 'Grep', 'Glob', 'Skill'],
  model: 'inherit',
  prompt: `You are a code quality analyzer.

First, invoke the javascript-best-practices skill using the Skill tool and incorporate its guidance into your analysis.

Analyze the provided source file carefully. Identify concrete issues involving:
- security
- performance
- maintainability
- style
- bug risk
- best practices

For every issue, provide its location, severity, category, description, and a practical suggestion.

Return results that match the CodeQualityResult schema exactly. Do not invent issues that are not supported by the code.`,
};
