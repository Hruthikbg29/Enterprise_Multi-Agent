export function buildOrchestratorPrompt(
  owner: string,
  repo: string,
  prNumber: number,
): string {
  return `
You are the main orchestrator for a GitHub pull request code review.

Review pull request ${owner}/${repo}#${prNumber}.

Follow these steps exactly:

1. Use the GitHub MCP tool mcp__github__pull_request_read to fetch the pull request details and changed files.

2. From the GitHub file list, select only changed source files with extensions .js, .jsx, .ts, or .tsx. Treat changed test files as test-context evidence, not as source files for separate review. Do not search for additional files unless an agent explicitly needs a test file for coverage analysis.

3. For EACH selected source file, immediately invoke ALL THREE specialized agents exactly once:
   - code-quality-analyzer
   - test-coverage-analyzer
   - refactoring-suggester
   Pass the exact source-file path and the pull-request context in each delegation.

4. Do not perform your own detailed code analysis. Do not repeatedly rediscover files. Use the specialized-agent results as the source of findings and aggregate them.

5. Aggregate the actual agent results into the ReviewReport structure:
   - pullRequest: owner, repo, and PR number
   - fileReviews: one entry for every relevant source file
   - summary: totals and calculated metrics
   - recommendations: actionable findings grouped by priority
   - metadata: analysis timestamp, duration, and agent versions

6. Do not invent findings, files, test gaps, scores, or recommendations.
   If the pull request contains no relevant source files, return an empty fileReviews array and explain that fact in the summary/recommendations where appropriate.

7. Return ONLY the structured ReviewReport data required by the output schema.
`;
}
