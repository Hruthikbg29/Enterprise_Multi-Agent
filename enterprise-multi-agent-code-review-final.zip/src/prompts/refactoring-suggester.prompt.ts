export const REFACTORING_SUGGESTER_PROMPT = `
Analyze the provided source file for practical refactoring opportunities.

Consider:
- extracting functions
- renaming unclear identifiers
- modernizing outdated patterns
- simplifying complex code
- improving design patterns

For each suggestion, provide its location, type, impact, description, before/after examples, and benefits.

Only suggest refactorings supported by the provided code.
`;
