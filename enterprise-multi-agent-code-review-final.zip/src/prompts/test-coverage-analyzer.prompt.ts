export const TEST_COVERAGE_ANALYZER_PROMPT = `
Analyze the provided source file and its available tests.

Identify important behavior that is not adequately covered, including:
- functions
- classes
- branches
- edge cases

For each testing opportunity, identify its location, priority, reasoning, and a concrete suggested test.

Base the analysis only on the source and available tests.
`;
