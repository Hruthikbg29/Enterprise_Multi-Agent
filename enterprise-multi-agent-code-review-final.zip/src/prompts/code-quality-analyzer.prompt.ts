export const CODE_QUALITY_ANALYZER_PROMPT = `
Analyze the provided source file for code quality issues.

Look for:
- security vulnerabilities
- performance problems
- maintainability concerns
- style problems
- bug risks
- violations of established best practices

For each issue, identify the location, severity, category, description, and suggested improvement.

Only report issues supported by the provided code.
`;
