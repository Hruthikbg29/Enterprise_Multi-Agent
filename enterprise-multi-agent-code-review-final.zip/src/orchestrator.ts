import { query } from '@anthropic-ai/claude-agent-sdk';
import type { ReviewReport } from './types/report-types';
import { ReviewReportSchema } from './types/report-types';
import { ReviewReportJSONSchema } from './types/report-types';
import { mcpServersConfig } from './config/mcp.config';
import {
  codeQualityAnalyzer,
  testCoverageAnalyzer,
  refactoringSuggester
} from './agents';
import { buildOrchestratorPrompt } from './prompts';
import { withRetry, withTimeout } from './utils/error-handler';
import { withRateLimit, globalRateLimiter } from './utils/rate-limiter';

export interface OrchestratorOptions {
  maxTurns?: number;
  maxBudgetUsd?: number;
}

export class CodeReviewOrchestrator {
  private readonly options: OrchestratorOptions;

  constructor(options: OrchestratorOptions = {}) {
    this.options = options;
  }

  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    const prompt = buildOrchestratorPrompt(owner, repo, prNumber);

    return withRateLimit(globalRateLimiter, async () => {
      return withRetry(async () => {
        return withTimeout(async () => {
          const messages = query({
            prompt,
            options: {
              cwd: process.cwd(),
              agents: {
                'code-quality-analyzer': codeQualityAnalyzer,
                'test-coverage-analyzer': testCoverageAnalyzer,
                'refactoring-suggester': refactoringSuggester
              },
              mcpServers: mcpServersConfig,
              allowedTools: [
                'Task',
                'Read',
                'Grep',
                'Glob',
                'mcp__github__pull_request_read',
                'mcp__github__get_pull_request',
                'mcp__github__get_pull_request_files'
              ],
              outputFormat: {
                type: 'json_schema',
                schema: ReviewReportJSONSchema
              },
              maxTurns: this.options.maxTurns ?? 10,
              maxBudgetUsd: this.options.maxBudgetUsd
            }
          });

          for await (const message of messages) {
      if (message.type !== 'result') {
        continue;
      }

      if (message.subtype !== 'success') {
        const errors = 'errors' in message ? message.errors : [];
        throw new Error(
          `Code review failed: ${errors.join('; ') || message.subtype}`
        );
      }

      if (!message.structured_output) {
        throw new Error('Code review completed without structured output');
      }

      const validatedReport = ReviewReportSchema.safeParse(message.structured_output);
      if (validatedReport.success === false) {
        throw new Error('Invalid ReviewReport: ' + validatedReport.error.message);
      }

      return validatedReport.data;
    }

          throw new Error('Code review produced no result');
        }, 300000, 'Code review timed out');
      }, 1, 1000);
    });
  }
}
